/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.Hack;

/**
 *
 * @author Camilo-Ov
 */
class HashGenerationException extends Exception {

    HashGenerationException(String could_not_generate_hash_from_String, java.lang.Exception ex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
